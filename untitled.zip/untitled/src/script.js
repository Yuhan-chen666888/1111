const io = require("socket.io")(3000);

let scores = { 1: 0, 2: 0 };
let leaderboard = [];
let words = [
    { en: "apple", zh: "蘋果" },
    { en: "banana", zh: "香蕉" },
    { en: "teacher", zh: "老師" },
    { en: "student", zh: "學生" }
];

io.on("connection", (socket) => {
    console.log("新玩家加入");

    socket.on("joinGame", () => {
        let word = words[Math.floor(Math.random() * words.length)];
        io.emit("newQuestion", word);
    });

    socket.on("checkAnswer", ({ answer, player }) => {
        let correct = words.find(w => w.en === answer);
        if (correct) {
            scores[player]++;
            io.emit("updateScores", scores);
        }

        let newWord = words[Math.floor(Math.random() * words.length)];
        io.emit("newQuestion", newWord);
    });

    socket.on("endGame", (winner) => {
        let player = leaderboard.find(p => p.name === `玩家 ${winner}`);
        if (player) {
            player.wins++;
        } else {
            leaderboard.push({ name: `玩家 ${winner}`, wins: 1 });
        }
        leaderboard.sort((a, b) => b.wins - a.wins);
        io.emit("updateLeaderboard", leaderboard.slice(0, 5));
    });
});
